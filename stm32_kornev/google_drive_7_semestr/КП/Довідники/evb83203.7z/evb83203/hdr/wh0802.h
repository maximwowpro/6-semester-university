#ifndef _WH0802_
#define _WH0802_

typedef enum {false = 0, true = 1} bool;

void WH0802_DelayMS(unsigned int Delay);
void WH0802_DelayUS(unsigned int Delay);
void WH0802_Init();
void WH0802_SendDC(unsigned char Data, bool DC);
void WH0802_WriteString(unsigned char* String, unsigned int Length, unsigned int Row);

#endif //!_WH0802_