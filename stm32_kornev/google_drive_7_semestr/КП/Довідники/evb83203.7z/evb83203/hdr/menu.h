#ifndef _MENU_
#define _MENU_

struct _control{
	unsigned char ITEM [2][8];
	unsigned char VALUE [2][8];
	unsigned int CurItem;
	unsigned int TurnOn;
	unsigned int Speed;	
	unsigned int Direction;
	unsigned int ItemValue;
};

struct _control CONTROL = {">SPEED: ", ">MT_DIR:",
													 " dc=05% ", " forward",
													 0,
													 0,
													 5,
													 0,
													 0};

#endif //!_MENU_