#include "stm32f10x_gpio.h"

/*
#include "tim.h"

#define RCC_APB2ENR_INIT 		(RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_IOPCEN | RCC_APB2ENR_AFIOEN)
#define GPIOC_CRH_INIT 			0x44444442
	
	void test12() {
//include required libraries
#include "stm32f10x_gpio.h"
#include "wh0802.h"
#include "menu3.h"
#include "main.h"



//define constants for initializing of necessary registers
//enable TIM7, GPIOA, GPIOB, GPIOC, AFIO and USART1 
#define RCC_APB1ENR_INIT 		(RCC_APB1ENR_TIM2EN | RCC_APB1ENR_TIM3EN | /*RCC_APB1ENR_TIM1EN |*/ RCC_APB1ENR_TIM7EN)
#define RCC_APB2ENR_INIT 		(RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_IOPCEN | RCC_APB2ENR_AFIOEN | RCC_APB2ENR_TIM1EN)
//define Pin8..11 of GPIOA as general purpose push-pull output with fmax = 2 MHz
#define GPIOA_CRH_INIT      0x44442222
//define Pin7 of GPIOB as floating input and Pin6 as AF push-pull output with fmax = 2 MHz
#define GPIOB_CRL_INIT 			0x444444aa
#define GPIOB_CRH_INIT 			0x4444a244
//define Pin10..12 of GPIOc as general purpose push-pull output with fmax = 2 MHz
#define GPIOC_CRH_INIT      0x444222a2
#define GPIOC_CRL_INIT      0x44424444
//define remapping for USART1
#define AFIO_MAPR_INIT			(AFIO_MAPR_TIM2_REMAP | AFIO_MAPR_TIM3_REMAP | AFIO_MAPR_TIM1_REMAP_0)
//define EXTI from GPIOA Pin0..2
#define EXTI_IMR_INIT				(0x00000006)
//define EXTI on rising edge from GPIOA Pin0..2
#define EXTI_RTSR_INIT			(0x00000006)
//enable handlers EXTI0 and EXTI1
#define NVIC_ISER0_INIT			(NVIC_ISER_SETENA_6 | NVIC_ISER_SETENA_7 | NVIC_ISER_SETENA_8)

void num2strm3() {
	unsigned int num, rem, duty;
	unsigned int item = 0;
	
	num = MENU3.CurValue[item];
	duty = num * 23999 / 100;
	//if (item == 0) {
		TIM3->CCR3 = duty;
		TIM3->CCR4 = duty;
	//}
	//if (item == 1) {
		TIM2->CCR3 = duty;
		TIM2->CCR4 = duty;
	//}
	/*if (item == 2) {
		TIM4->CCR3 = num * 23999 / 100;
		TIM4->CCR4 = num * 23999 / 100;
	}
*/	
	if (num == 100) {
		MENU3.VALUE[item][3] = 0x31;
		MENU3.VALUE[item][4] = 0x30;
		MENU3.VALUE[item][5] = 0x30;
	}
	else {
		MENU3.VALUE[item][3] = ' ';
		MENU3.VALUE[item][4] = (num / 10) | 0x30;
		rem = num % 10;
		MENU3.VALUE[item][5] = rem | 0x30;
	}
	
}


/*******************************************************************/
/*******************control menu procedure**************************/
/*******************************************************************/
void chng_menu3() {
	
	//variable - counter
	unsigned int i;

	//if pressed button "rotate"
/*	if (1 == MENU3.Exti_flag) {
			//decrement variable MENU3.CurItem
			if (MENU3.CurItem < MAX_ITEM) ++(MENU3.CurItem);
			//if its value greater than zero
			else MENU3.CurItem = 0;
	}
*/	//if pressed button "down"
	if (2 == MENU3.Exti_flag) {
			if (MENU3.CurValue[MENU3.CurItem] > 5) {
				MENU3.CurValue[MENU3.CurItem] -= 1;
				num2strm3(MENU3.CurItem);
			}
	}
	//if pressed button "up"
	if (3 == MENU3.Exti_flag) {
			if (MENU3.CurValue[MENU3.CurItem] < 95) {
				MENU3.CurValue[MENU3.CurItem] += 1;
				num2strm3(MENU3.CurItem);
			}
	}
	//display menu items
	lcd_str (MENU3.ITEM[MENU3.CurItem], ITEM_LEN, 1);
	lcd_str (MENU3.VALUE[MENU3.CurItem], ITEM_LEN, 2);
	//clear press button flag
	MENU3.Exti_flag = 0;
}

/*******************************************************************/
/*******************test program procedure**************************/
/*******************************************************************/
void test7() {
	
	//enable desired periphery
	RCC->APB1ENR = RCC_APB1ENR_INIT;
	RCC->APB2ENR = RCC_APB2ENR_INIT;
	//initialize ports GPIOA, GPIOB, GPIOC and AFIO
	GPIOA->CRH = GPIOA_CRH_INIT;
	GPIOB->CRL = GPIOB_CRL_INIT;
	GPIOB->CRH = GPIOB_CRH_INIT;
	GPIOC->CRL = GPIOC_CRL_INIT;
	GPIOC->CRH = GPIOC_CRH_INIT;
	AFIO->MAPR = AFIO_MAPR_INIT;
	//initialize EXTI
	EXTI->IMR = EXTI_IMR_INIT;
	EXTI->RTSR = EXTI_RTSR_INIT;
	//initialize NVIC
	NVIC->ISER[0] = NVIC_ISER0_INIT;
	
	//GPIOB->ODR &= ~(1<<0);
	//GPIOB->ODR &= ~(1<<1);
	
	GPIOC->ODR &= ~(1<<4);
	GPIOC->ODR |= (1<<8);
	GPIOB->ODR |= (1<<10);
	
	//initialize display
	lcd_init();
	//display menu items
	lcd_str (MENU3.ITEM[MENU3.CurItem], 8, 1);
	lcd_str (MENU3.VALUE[MENU3.CurItem], 8, 2);
/*
	TIM1->CR1 |= TIM_CR1_ARPE;
  TIM1->CCMR2 |= (TIM_CCMR1_OC2PE | TIM_CCMR1_OC2M_2 | TIM_CCMR1_OC2M_1 | TIM_CCMR2_OC3PE | TIM_CCMR2_OC3M_2 | TIM_CCMR2_OC3M_1);
  TIM1->ARR = 23999;
  TIM1->CCR2 = 11999;
	TIM1->CCR3 = 11999;
  TIM1->CCER |= (TIM_CCER_CC2E | TIM_CCER_CC3E | TIM_CCER_CC3P);
*/
	TIM2->CR1 |= TIM_CR1_ARPE;
  TIM2->CCMR2 |= (TIM_CCMR2_OC3PE | TIM_CCMR2_OC3M_2 | TIM_CCMR2_OC3M_1 | TIM_CCMR2_OC4PE | TIM_CCMR2_OC4M_2 | TIM_CCMR2_OC4M_1);
  TIM2->ARR = 23999;
  TIM2->CCR3 = 11999;
	TIM2->CCR4 = 11999;
  TIM2->CCER |= (TIM_CCER_CC3E | TIM_CCER_CC4E | TIM_CCER_CC3P);
	
	TIM3->CR1 |= TIM_CR1_ARPE;
  TIM3->CCMR2 |= (TIM_CCMR2_OC3PE | TIM_CCMR2_OC3M_2 | TIM_CCMR2_OC3M_1 | TIM_CCMR2_OC4PE | TIM_CCMR2_OC4M_2 | TIM_CCMR2_OC4M_1);
  TIM3->ARR = 23999;
  TIM3->CCR3 = 11999;
	TIM3->CCR4 = 11999;
  TIM3->CCER |= (TIM_CCER_CC3E | TIM_CCER_CC4E | TIM_CCER_CC4P);

/*
	TIM4->CR1 |= TIM_CR1_ARPE;
  TIM4->CCMR2 |= (TIM_CCMR2_OC3PE | TIM_CCMR2_OC3M_2 | TIM_CCMR2_OC3M_1 | TIM_CCMR2_OC4PE | TIM_CCMR2_OC4M_2 | TIM_CCMR2_OC4M_1);
  TIM4->ARR = 23999;
  TIM4->CCR3 = 11999;
	TIM4->CCR4 = 11999;
  TIM4->CCER |= (TIM_CCER_CC3E | TIM_CCER_CC4E | TIM_CCER_CC4P);
*/
	GPIOC->ODR |= (1<<4);
	//TIM1->CR1 |= TIM_CR1_CEN;
	TIM2->CR1 |= TIM_CR1_CEN;
	TIM3->CR1 |= TIM_CR1_CEN;
//	TIM4->CR1 |= TIM_CR1_CEN;

	while (1) {
		//if button was pressed, do required changes
		if (MENU3.Exti_flag) chng_menu3();
		//enjoy the infinity of wonderful life:)
	}
}
	
/*******************************************************************/
/******************interrupt handler EXTI0**************************/
/*******************************************************************/
/*
#if (PROGNO == 7)
void EXTI0_IRQHandler(void) {
	//disable interrupt EXTI0
	EXTI->IMR&= ~EXTI_IMR_MR0;
	//20 ms delay for protection from contact bounce
	delay_ms(20);
	//if pin established in high level
	if ((GPIOA->IDR)&(GPIO_Pin_0)) MENU3.Exti_flag = 1;
	//clear flag
	EXTI->PR|= EXTI_PR_PR1;
	//enable interrupt from EXTI0
	EXTI->IMR|=(EXTI_IMR_MR0);
}
#endif
*/
/*******************************************************************/
/******************interrupt handler EXTI1**************************/
/*******************************************************************/
#if (PROGNO == 7)
void EXTI1_IRQHandler(void) {
	//disable interrupt EXTI1
	EXTI->IMR&= ~EXTI_IMR_MR1;
	//20 ms delay for protection from contact bounce
	delay_ms(20);
	//if pin established in high level
	if ((GPIOA->IDR)&(GPIO_Pin_1)) MENU3.Exti_flag = 2;
	EXTI->PR|= EXTI_PR_PR1;
	//enable interrupt from EXTI1
	EXTI->IMR|=(EXTI_IMR_MR1);
}
#endif

/*******************************************************************/
/******************interrupt handler EXTI2**************************/
/*******************************************************************/
#if (PROGNO == 7)
void EXTI2_IRQHandler(void) {
	//disable interrupt EXTI2
	EXTI->IMR&= ~EXTI_IMR_MR2;
	//20 ms delay for protection from contact bounce
	delay_ms(20);
	//if pin established in high level
	if ((GPIOA->IDR)&(GPIO_Pin_2)) MENU3.Exti_flag = 3;
	//clear flag
	EXTI->PR|= EXTI_PR_PR2;
	//enable interrupt from EXTI2
	EXTI->IMR|=(EXTI_IMR_MR2);
}
#endif


		
	while (1) {
		GPIOC->ODR |= (1<<8); 
		delay_ms(500);
		GPIOC->ODR &= ~(1<<8); 
		delay_ms(500);
}
}

#ifndef _TEST7_
#define _TEST7_

void num2strm3(unsigned int item);
void chng_menu3();
void test7();

#endif //!_TEST7_

//include required libraries
#include "stm32f10x.h"
#include "tim.h"

//define ports for data and commands for display
#define LCD_DATA_PORT		GPIOA->ODR
#define LCD_COM_PORT		GPIOC->ODR
//define pin number for every display pin
#define	LCD_D4				(1<<8)
#define	LCD_D5				(1<<9)
#define	LCD_D6				(1<<10)
#define	LCD_D7				(1<<11)
#define	LCD_RS				(1<<10)
#define LCD_RW				(1<<11)
#define	LCD_E					(1<<12)

/*******************************************************************/
/****sending data/commands to the controller display procedure******/
/*******************************************************************/
void lcd_data(unsigned char data, unsigned int RS)
{
	//if RS = 1, send data
	if (RS) LCD_COM_PORT|= LCD_RS;
	//else send command
	else LCD_COM_PORT&= ~LCD_RS;
	//set to the data bus desired levels (high tetrad)
	LCD_DATA_PORT&=~(LCD_D4|LCD_D5|LCD_D6|LCD_D7);
	if ((data&(1<<7))!=0) LCD_DATA_PORT|=LCD_D7;
	if ((data&(1<<6))!=0) LCD_DATA_PORT|=LCD_D6;
	if ((data&(1<<5))!=0) LCD_DATA_PORT|=LCD_D5;
	if ((data&(1<<4))!=0) LCD_DATA_PORT|=LCD_D4;
	//form strobe signal
	LCD_COM_PORT|=LCD_E;
	delay_us(2);
	LCD_COM_PORT&=~LCD_E;
	delay_us(10);
	//set to the data bus desired levels (low tetrad)
	LCD_DATA_PORT&=~(LCD_D4|LCD_D5|LCD_D6|LCD_D7);
	if ((data&(1<<3))!=0) LCD_DATA_PORT|=LCD_D7;
	if ((data&(1<<2))!=0) LCD_DATA_PORT|=LCD_D6;
	if ((data&(1<<1))!=0) LCD_DATA_PORT|=LCD_D5;
	if ((data&(1<<0))!=0) LCD_DATA_PORT|=LCD_D4;
	//form strobe signal
	LCD_COM_PORT|=LCD_E;
	delay_us(2);
	LCD_COM_PORT&=~LCD_E;
	delay_us(40);
}

/*******************************************************************/
/***************display string procedure****************************/
/*******************************************************************/
void lcd_str(unsigned char* data, unsigned int length, unsigned int row)
{
	//variable - counter
	unsigned int i;

	if ((row == 1) || (row == 2)) {
		//set cursor on desired position
		if (row == 1) lcd_data(0x80, 0);
		if (row == 2) lcd_data(0xC0, 0);
		//derive data to display
		for (i = 0; i < length; ++i) {
			lcd_data(data[i], 1);
		}
	}
}


/*******************************************************************/
/***********initialization display pocedure (from datasheet)********/
/*******************************************************************/
void lcd_init()
{
	//set R/W = 0 (write only)
	LCD_COM_PORT&=~LCD_RW;
	//delay 50 ms
	delay_ms(50);
	//set transfer interface (four-wire)
	//0x001 DL 0000, DL = 1
	lcd_data(0x30, 0);
	//delay 50 us
	delay_us(50);
	//set count of strings (2) and size of symbols (5*8 pixels)
	//0x0010 N F 00, N = 1, F = 0
	lcd_data(0x28, 0);
	//delay 50 us
	delay_us(50);
	//0x0010 N F 00, N = 1, F = 0
	lcd_data(0x28, 0);
	//delay 50 us
	delay_us(50);
	//switching-on the display, setting and flashing of cursor
	//0x0000 1 D C B, D = 1, C = 1, B = 0
	lcd_data(0x0c, 0);
	//delay 50 us
	delay_us(50);
	//clear display
	lcd_data(0x01, 0);
	//delay 2 ms
	delay_ms(2);
	//set dial mode
	//0x0000 01 I/D SH, I/D = 1, SH = 0
	lcd_data(0x06, 0);
}

//include required libraries
#include "stm32f10x.h"

//define frequency of timer-counter
#define	F_APB1				24000000

/*******************************************************************/
/**********************delay procedure (ms)*************************/
/*******************************************************************/
void delay_ms(unsigned int delay)
{
	//define frequency prescaler
	TIM7->PSC = F_APB1/1000+1;
	//define value of timer overflow
	TIM7->ARR = delay;
	//define reinitialization when timer is overflowed
	TIM7->EGR |= TIM_EGR_UG;
	//enable timer and set the single pass
	TIM7->CR1 |= TIM_CR1_CEN|TIM_CR1_OPM;
	//wait for timer stopping
	while (TIM7->CR1&TIM_CR1_CEN!=0);
}

/*******************************************************************/
/**********************delay procedure (us)*************************/
/*******************************************************************/
void delay_us(unsigned int delay)
{
	//define frequency prescaler
	TIM7->PSC = F_APB1/1000000+1;
	//define value of timer overflow
	TIM7->ARR = delay;
	//define reinitialization when timer is overflowed
	TIM7->EGR |= TIM_EGR_UG;
	//enable timer and set the single pass
	TIM7->CR1 |= TIM_CR1_CEN|TIM_CR1_OPM;
	//wait for timer stopping
	while (TIM7->CR1&TIM_CR1_CEN!=0);
}

#ifndef _WH0802_
#define _WH0802_

//sending data/commands to the controller display procedure
void lcd_data(unsigned char data, unsigned int RS);
//display string procedure
void lcd_str(unsigned char* data, unsigned int length, unsigned int row);
//initialization display procedure (from datasheet)
void lcd_init();

#endif //!_WH0802_

#ifndef _MENU3_
#define _MENU3_

//define constant of maximum value of CurItem
#define MAX_ITEM 2
//and length of item string
#define ITEM_LEN 8

//define structure for work with menu
struct _menu3{
	//array of item's strings
	unsigned char ITEM [3][8];
	//array of strings of item's values
	unsigned char VALUE [3][8];
	//current value of item
	unsigned int CurItem;
	//array of current values of items
	uint32_t CurValue [3];
	//push button event flag
	unsigned int Exti_flag;
};

typedef struct _menu3 _menu3;

//initializing of structure for working with menu
_menu3 MENU3 = {">PWM:   ", ">PWM2:  ", ">PWM3:  ",
								" d: 50% ", " d: 50% ", " d: 50% ",
								0,
								50, 50, 50,
								0};

#endif //!_MENU3_
#ifndef _TIM_
#define _TIM_

//delay procedure (ms)
void delay_ms(unsigned int delay);
//delay procedure (us)
void delay_us(unsigned int delay);

#endif //!_TIM_
