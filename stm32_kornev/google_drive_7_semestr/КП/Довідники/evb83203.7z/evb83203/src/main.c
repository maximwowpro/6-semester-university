#include "stm32f10x_gpio.h"
#include "wh0802.h"
#include "menu.h"
 
#define RCC_APB1ENR_INIT 		(RCC_APB1ENR_TIM2EN | RCC_APB1ENR_TIM3EN | RCC_APB1ENR_TIM6EN)
#define RCC_APB2ENR_INIT 		(RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_IOPCEN |\
														RCC_APB2ENR_AFIOEN | RCC_APB2ENR_USART1EN)

#define GPIOA_CRH_INIT      0x44442222
#define GPIOB_CRL_INIT 			0x4a444444
#define GPIOB_CRH_INIT 			0x4444a244
#define GPIOC_CRL_INIT      0x44424444
#define GPIOC_CRH_INIT      0x444222a2

#define AFIO_MAPR_INIT			(AFIO_MAPR_TIM2_REMAP | AFIO_MAPR_TIM3_REMAP | AFIO_MAPR_USART1_REMAP)

#define USART1_BRR_INIT			(0x9c4)
#define USART1_CR1_INIT 		(USART_CR1_UE | USART_CR1_TE | USART_CR1_RE | USART_CR1_TCIE | USART_CR1_RXNEIE)

#define EXTI_IMR_INIT				0x0000000f
#define EXTI_RTSR_INIT			0x0000000f

#define NVIC_ISER0_INIT			(NVIC_ISER_SETENA_6 | NVIC_ISER_SETENA_7 | NVIC_ISER_SETENA_8 | NVIC_ISER_SETENA_9)
#define NVIC_ISER1_INIT			(NVIC_ISER_SETENA_5)

uint32_t PrButton = 0;

void MOTOR_Start() {
	unsigned int MHSpeed;
	unsigned int MLSpeed = 240;
		if (!CONTROL.Direction) {
			MHSpeed = CONTROL.Speed * 24000 / 100;
			TIM3->CCR4 = 23760;
		}
		else	{
			MHSpeed = CONTROL.Speed * 24000 / 100;
			TIM2->CCR4 = 240;
		}
		
		GPIOC->ODR |= (1<<4);
		TIM2->CR1 |= TIM_CR1_CEN;
		TIM3->CR1 |= TIM_CR1_CEN;
		
		while (MHSpeed >= MLSpeed) {
			if (!CONTROL.Direction) TIM2->CCR4 = MLSpeed;
			else TIM3->CCR4 = 24000 - MLSpeed;
			WH0802_DelayMS(25);
			MLSpeed += 240;
		}
}

void MOTOR_UpdateSpeed() {
		if (!CONTROL.Direction) {
			TIM2->CCR4 = CONTROL.Speed * 24000 / 100;
			TIM3->CCR4 = 23760;
		}
		else	{
			TIM3->CCR4 = (100 - CONTROL.Speed) * 24000 / 100;
			TIM2->CCR4 = 240;
		}
}

void MOTOR_Stop() {
	unsigned int MHSpeed;
	unsigned int MLSpeed = 240;
	
	if (!CONTROL.Direction) {
		MHSpeed = CONTROL.Speed * 24000 / 100;
		TIM3->CCR4 = 23760;
	}
	else	{
		MHSpeed = CONTROL.Speed * 24000 / 100;
		TIM2->CCR4 = 240;
	}
	
	while (MHSpeed >= MLSpeed) {
		if (!CONTROL.Direction) TIM2->CCR4 = MHSpeed;
		else TIM3->CCR4 = 24000 - MHSpeed;
		WH0802_DelayMS(25);
		MHSpeed -= 240;
	}
	
	GPIOC->ODR &= ~(1<<4);
	TIM2->CR1 &= ~TIM_CR1_CEN;
	TIM3->CR1 &= ~TIM_CR1_CEN;
}

void MENU_UpdateSpeed(unsigned int Speed) {
	CONTROL.VALUE[0][0] = '>';
	CONTROL.VALUE[0][4] = (Speed / 10) | 0x30;
	CONTROL.VALUE[0][5] = (Speed % 10) | 0x30;
	MOTOR_UpdateSpeed();
}

void MENU_UpdateDirection(unsigned int Direction) {
	if (!Direction) {
		CONTROL.VALUE[1][0] = '>'; CONTROL.VALUE[1][1] = 'f';
		CONTROL.VALUE[1][2] = 'o'; CONTROL.VALUE[1][3] = 'r';
		CONTROL.VALUE[1][4] = 'w'; CONTROL.VALUE[1][5] = 'a';
		CONTROL.VALUE[1][6] = 'r'; CONTROL.VALUE[1][7] = 'd';
	}
	else {
		CONTROL.VALUE[1][0] = '>'; CONTROL.VALUE[1][1] = 'r';
		CONTROL.VALUE[1][2] = 'e'; CONTROL.VALUE[1][3] = 'v';
		CONTROL.VALUE[1][4] = 'e'; CONTROL.VALUE[1][5] = 'r';
		CONTROL.VALUE[1][6] = 's'; CONTROL.VALUE[1][7] = 'e';
	}
}

void MENU_Update(unsigned int Button) {
	
	if (Button == 1) {
		if (!CONTROL.ItemValue) {
			if (CONTROL.CurItem) CONTROL.CurItem = 0;
			else CONTROL.CurItem = 1;
		}
		else {
			if (CONTROL.CurItem == 0) {
				if (CONTROL.Speed > 5) CONTROL.Speed -= 5;
				else CONTROL.Speed = 5;
			MENU_UpdateSpeed(CONTROL.Speed);
			}
			else {
				if (CONTROL.Direction) CONTROL.Direction = 0;
				else CONTROL.Direction = 1;
				MENU_UpdateDirection(CONTROL.Direction);
			}			
		}
	}
	
	if (Button == 2) {
		if (!CONTROL.ItemValue) {
			CONTROL.ItemValue = 1;
			CONTROL.ITEM[CONTROL.CurItem][0] = ' ';
			CONTROL.VALUE[CONTROL.CurItem][0] = '>';
		}
		else {
			CONTROL.ItemValue = 0;
			CONTROL.ITEM[CONTROL.CurItem][0] = '>';
			CONTROL.VALUE[CONTROL.CurItem][0] = ' ';
		}
	}
	
	if (Button == 3) {
		if (!CONTROL.ItemValue) {
			if (!CONTROL.CurItem) CONTROL.CurItem = 1;
			else CONTROL.CurItem = 0;
		}
		else {
			if (CONTROL.CurItem == 0) {
				if (CONTROL.Speed < 95) CONTROL.Speed += 5;
				else CONTROL.Speed = 95;
				MENU_UpdateSpeed(CONTROL.Speed);
			}
			else {
				if (CONTROL.TurnOn) MOTOR_Stop();
				if (CONTROL.Direction) CONTROL.Direction = 0;
				else CONTROL.Direction = 1;
				MENU_UpdateDirection(CONTROL.Direction);
				if (CONTROL.TurnOn) MOTOR_Start();
			}	
		}
	}
	if (Button == 4) {
		if (CONTROL.TurnOn) {
			CONTROL.TurnOn = 0;
			MOTOR_Stop();
		} 
		else {
			CONTROL.TurnOn = 1;
			MOTOR_Start(); 
		}
	}
	if (Button == 5) {
		EXTI->IMR &= ~EXTI_IMR_INIT;
		if (!CONTROL.TurnOn) {
			CONTROL.Direction = 0;
			MENU_UpdateDirection(CONTROL.Direction);
			CONTROL.Speed = 5;
			MENU_UpdateSpeed(CONTROL.Speed);
			CONTROL.TurnOn = 1;
			MOTOR_Start();
		} 
	}
	if (Button == 6) {
		EXTI->IMR |= EXTI_IMR_INIT;
		if (CONTROL.TurnOn) {
			CONTROL.TurnOn = 0;
			MOTOR_Stop();
		} 
	}
	if (Button == 7) {
		if (CONTROL.TurnOn) MOTOR_Stop();
		if (CONTROL.Direction) CONTROL.Direction = 0;
		else CONTROL.Direction = 1;
		MENU_UpdateDirection(CONTROL.Direction);
		if (CONTROL.TurnOn) MOTOR_Start();
	}
	if (Button == 8) {
		if ((CONTROL.Speed >= 5) && (CONTROL.Speed <= 95))
		MENU_UpdateSpeed(CONTROL.Speed);
	}
}

void main(void) {

	RCC->APB1ENR |= RCC_APB1ENR_INIT;
	RCC->APB2ENR |= RCC_APB2ENR_INIT;
	
	GPIOA->CRH = GPIOA_CRH_INIT;
	GPIOB->CRL = GPIOB_CRL_INIT;
	GPIOB->CRH = GPIOB_CRH_INIT;
	GPIOC->CRL = GPIOC_CRL_INIT;
	GPIOC->CRH = GPIOC_CRH_INIT;
	AFIO->MAPR = AFIO_MAPR_INIT;
	
	USART1->BRR = USART1_BRR_INIT;
	USART1->CR1 = USART1_CR1_INIT;
	
	EXTI->IMR = EXTI_IMR_INIT;
	EXTI->RTSR = EXTI_RTSR_INIT;
	
	NVIC->ISER[0] = NVIC_ISER0_INIT;
	NVIC->ISER[1] = NVIC_ISER1_INIT;
	
	GPIOC->ODR &= ~(1<<4);
	GPIOC->ODR |= (1<<8);
	GPIOB->ODR |= (1<<10);

	TIM2->CR1 |= TIM_CR1_ARPE;
  TIM2->CCMR2 |= (TIM_CCMR2_OC4PE | TIM_CCMR2_OC4M_2 | TIM_CCMR2_OC4M_1);
  TIM2->ARR = 24000;
	TIM2->CCR4 = 1200;
  TIM2->CCER |= (TIM_CCER_CC4E);
	
	TIM3->CR1 |= TIM_CR1_ARPE;
  TIM3->CCMR2 |= (TIM_CCMR2_OC4PE | TIM_CCMR2_OC4M_2 | TIM_CCMR2_OC4M_1);
  TIM3->ARR = 24000;
	TIM3->CCR4 = 22800;
  TIM3->CCER |= (TIM_CCER_CC4E | TIM_CCER_CC4P);
	
	WH0802_Init();
	WH0802_WriteString(CONTROL.ITEM[CONTROL.CurItem], 8, 1);
	WH0802_WriteString(CONTROL.VALUE[CONTROL.CurItem], 8, 2);
	
	while (1) {
		if (PrButton) {
			MENU_Update(PrButton);
			WH0802_WriteString(CONTROL.ITEM[CONTROL.CurItem], 8, 1);
			WH0802_WriteString(CONTROL.VALUE[CONTROL.CurItem], 8, 2);
			PrButton = 0;
		}
	}
	
}

void EXTI0_IRQHandler(void) {
	EXTI->IMR &= ~EXTI_IMR_MR0;
	WH0802_DelayMS(20);
	if ((GPIOA->IDR)&(GPIO_Pin_0)) PrButton = 1;
	EXTI->PR |= EXTI_PR_PR1;
	EXTI->IMR |=(EXTI_IMR_MR0);
}

void EXTI1_IRQHandler(void) {
	EXTI->IMR &= ~EXTI_IMR_MR1;
	WH0802_DelayMS(20);
	if ((GPIOA->IDR)&(GPIO_Pin_1)) PrButton = 2;
	EXTI->PR |= EXTI_PR_PR1;
	EXTI->IMR |= (EXTI_IMR_MR1);
}

void EXTI2_IRQHandler(void) {
	EXTI->IMR&= ~EXTI_IMR_MR2;
	WH0802_DelayMS(20);
	if ((GPIOA->IDR)&(GPIO_Pin_2)) PrButton = 3;
	EXTI->PR|= EXTI_PR_PR2;
	EXTI->IMR|=(EXTI_IMR_MR2);
}

void EXTI3_IRQHandler(void) {
	EXTI->IMR&= ~EXTI_IMR_MR3;
	WH0802_DelayMS(20);
	if ((GPIOA->IDR)&(GPIO_Pin_3)) PrButton = 4;
	EXTI->PR|= EXTI_PR_PR3;
	EXTI->IMR|=(EXTI_IMR_MR3);
}

void USART1_IRQHandler(void) {
	unsigned int USARTData;
	if (USART1->SR & USART_SR_RXNE) {
		USART1->SR &= ~USART_SR_RXNE;
		USARTData = USART1->DR;
		if (USARTData == 0x20) PrButton = 5;
		if (USARTData == 0x40) PrButton = 7;
		if (USARTData == 0x60) PrButton = 6;
		if ((USARTData & 0xe0) == 0x80) {
			CONTROL.Speed = (USARTData & 0x1f) * 5;
			PrButton = 8;
		}
	}
	if (USART1->SR & USART_SR_TC) {
		USART1->SR &= ~USART_SR_TC;
	}
}


