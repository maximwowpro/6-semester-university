#include "stm32f10x_gpio.h"
#include "wh0802.h"

#define DATA_PORT		GPIOA->ODR
#define COM_PORT		GPIOC->ODR

#define	DB4					(1<<8)
#define	DB5					(1<<9)
#define	DB6					(1<<10)
#define	DB7					(1<<11)
#define	RS					(1<<10)
#define RW					(1<<11)
#define	E						(1<<12)

#define	F_APB1			24000000
#define WH0802_TIM	TIM6

void WH0802_DelayMS(unsigned int Delay) {

	WH0802_TIM->PSC = F_APB1/1000+1;
	WH0802_TIM->ARR = Delay;
	WH0802_TIM->EGR |= TIM_EGR_UG;
	WH0802_TIM->CR1 |= TIM_CR1_CEN|TIM_CR1_OPM;
	while (WH0802_TIM->CR1&TIM_CR1_CEN!=0);
	
}

void WH0802_DelayUS(unsigned int Delay) {

	WH0802_TIM->PSC = F_APB1/1000000+1;
	WH0802_TIM->ARR = Delay;
	WH0802_TIM->EGR |= TIM_EGR_UG;
	WH0802_TIM->CR1 |= TIM_CR1_CEN|TIM_CR1_OPM;
	while (WH0802_TIM->CR1&TIM_CR1_CEN!=0);
	
}

void WH0802_SendDC(unsigned char Data, bool DC) {
	
	if (DC) COM_PORT |= RS;
	else COM_PORT &= ~ RS;
	
	DATA_PORT &= ~ (DB4 | DB5 | DB6 | DB7);
	if (Data & (1<<7)) DATA_PORT |= DB7;
	if (Data & (1<<6)) DATA_PORT |= DB6;
	if (Data & (1<<5)) DATA_PORT |= DB5;
	if (Data & (1<<4)) DATA_PORT |= DB4;

	COM_PORT |= E;
	WH0802_DelayUS(2);
	COM_PORT &= ~E;
	WH0802_DelayUS(10);

	DATA_PORT &= ~ (DB4 | DB5 | DB6 | DB7);
	if (Data & (1<<3)) DATA_PORT |= DB7;
	if (Data & (1<<2)) DATA_PORT |= DB6;
	if (Data & (1<<1)) DATA_PORT |= DB5;
	if (Data & (1<<0)) DATA_PORT |= DB4;
	
	COM_PORT |= E;
	WH0802_DelayUS(2);
	COM_PORT &= ~E;
	WH0802_DelayUS(40);
	
}

void WH0802_WriteString(unsigned char* String, unsigned int Length, unsigned int Row) {
	unsigned int i;
	
	if ((Row == 1) || (Row == 2)) {
		if (Row == 1) WH0802_SendDC(0x80, 0);
		if (Row == 2) WH0802_SendDC(0xC0, 0);
		for (i = 0; i < Length; ++i) WH0802_SendDC(String[i], 1);
	}
}

void WH0802_Init() {

	COM_PORT &= ~RW;
	WH0802_DelayMS(50);
	WH0802_SendDC(0x30, 0);//0b001/DL/0000, DL = 1
	WH0802_DelayUS(50);
	WH0802_SendDC(0x28, 0);//0b0010/N/F/00, N = 1, F = 0
	WH0802_DelayUS(50);
	WH0802_SendDC(0x28, 0);//0b0010/N/F/00, N = 1, F = 0
	WH0802_DelayUS(50);
	WH0802_SendDC(0x0c, 0);//0b0000/1/D/C/B, D = 1, C = 1, B = 0
	WH0802_DelayUS(50);
	WH0802_SendDC(0x01, 0);//clear display
	WH0802_DelayMS(2);//delay 2 ms
	WH0802_SendDC(0x06, 0);//0x0000 01 I/D SH, I/D = 1, SH = 0
	
}
