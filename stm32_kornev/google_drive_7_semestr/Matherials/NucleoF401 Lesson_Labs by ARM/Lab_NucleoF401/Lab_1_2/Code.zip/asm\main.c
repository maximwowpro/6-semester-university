/*----------------------------------------------------------------------------
LAB EXERCISE 5.1 - PROCESSING TEXT IN ASSEMBLY LANGUAGE
 ----------------------------------------------
Examine program execution at the processor level using the debugger 
 *----------------------------------------------------------------------------*/

__asm void my_strcpy(const char *src, char *dst){
	
	//Write your code here
	
}

__asm void my_capitalize(char *str){
	
	//Write your code here
	
}

/*----------------------------------------------------------------------------
 MAIN function
 *----------------------------------------------------------------------------*/

int main(void){
	
	//Write your code here
	
}

// *******************************ARM University Program Copyright (c) ARM Ltd 2014*************************************
